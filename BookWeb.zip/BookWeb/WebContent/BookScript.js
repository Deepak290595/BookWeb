
function validateNewBookPage(){
	if(validateId("bookid",/^[0-9]+$/)){
		if(validateBName("bookname", /^[A-Za-z ]+$/)){
			if(validateAName("bookauthor",/^[A-Za-z ]+$/ )){
				if(validateButton("genre")){
					if(validatePrice("price",/^[0-9]+$/)){
						if(validateCheckboxes("Publishers"))
								return true;
					}
				}
			}return false;
		}
		return false;
	}else
		return false;
}

function validateId(fieldname,regex){
	var object = document.forms["book"][fieldname];
	if(object.value.match(regex))
		return true;
	else
	{
		window.alert(fieldname+" should be number");
		object.focus();
		return false;
	}
}
function validateBName(fieldname,regex){
		var object = document.forms["book"][fieldname];
		if(object.value.match(regex))
			return true;
		else
		{
			window.alert(fieldname+" should be alphabets");
			object.focus();
			return false;
		}
	}
function validateAName(fieldname,regex){
		var object = document.forms["book"][fieldname];
		if(object.value.match(regex))
			return true;
		else
		{
			window.alert(fieldname+" should be alphabets");
			object.focus();
			return false;
		}
	}
function validatePrice(fieldname,regex){
		var object = document.forms["book"][fieldname];
		if(object.value.match(regex))
			return true;
		else
		{
			window.alert(fieldname+" should be number");
			object.focus();
			return false;
		}
	}
function validateButton(fieldname){
	var object = document.forms["book"][fieldname];
	if(!object[0].checked&&!object[1].checked&&!object[2].checked)
	{
		window.alert("Choose Genre");
		object[0].focus();
		return false;
	}
	else
		return true;
}
function validateCheckboxes(fieldname){
	var object = document.forms["book"][fieldname];
	if(!object[0].checked&&!object[1].checked&&!object[2].checked&&!object[3].checked)
	{
		window.alert("Choose atleast one publisher");
		object[0].focus();
		return false;
	}
	else
		return true;
}