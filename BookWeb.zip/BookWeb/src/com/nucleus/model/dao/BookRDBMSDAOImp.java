package com.nucleus.model.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.model.connection.ConnectionFactory;
import com.nucleus.model.connection.ConnectionSetup;
import com.nucleus.model.domain.Book;

public class BookRDBMSDAOImp implements BookDAO {
	ConnectionSetup connectionSetup = ConnectionFactory.getConnection("oracle");
	Connection connection;
	PreparedStatement preparedStatement;
	ResultSet resultSet;
	public BookRDBMSDAOImp(){
		connection = connectionSetup.createConnection();
	}
	@Override
	public void save(Book book) {
		try {
			preparedStatement = connection.prepareStatement("insert into bookbydeepak values(?,?,?,?,?,?,to_date(?,'YYYY-MM-DD'),?)");
			preparedStatement.setInt(1, book.getbID());
			preparedStatement.setString(2, book.getbName());
			preparedStatement.setString(3, book.getbAuthor());
			preparedStatement.setString(4, book.getbGenre());
			preparedStatement.setInt(5, book.getbPrice());
			preparedStatement.setString(6, book.getbPublisher());
			preparedStatement.setString(7, book.getbPublishingDate());
			preparedStatement.setString(8, book.getbDiscription());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Book view(int bookID) {
		try {
			preparedStatement = connection.prepareStatement("select * from bookbydeepak where bid=?");
			preparedStatement.setInt(1, bookID);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				int bID = resultSet.getInt(1);
				String bName = resultSet.getString(2);
				String bAuthor = resultSet.getString(3);
				String bGenre = resultSet.getString(4);
				int bPrice = resultSet.getInt(5);
				String bPublishers = resultSet.getString(6);
				String bPublishingdate = resultSet.getString(7);
				String bDiscription = resultSet.getString(8);
				System.out.println(bID+" "+bName+" "+bAuthor+" "+bGenre+" "
				+bPrice+" "+bPublishers+" "+bPublishingdate+" "+bDiscription);
				Book book = new Book(bID, bName, bAuthor, bGenre, bPrice, bPublishers, bPublishingdate, bDiscription);
				return book;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Book> view() {
		ArrayList <Book> al = new ArrayList<Book>();
		try {
			preparedStatement = connection.prepareStatement("select * from bookbydeepak");
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				int bID = resultSet.getInt(1);
				String bName = resultSet.getString(2);
				String bAuthor = resultSet.getString(3);
				String bGenre = resultSet.getString(4);
				int bPrice = resultSet.getInt(5);
				String bPublishers = resultSet.getString(6);
				String bPublishingdate = resultSet.getString(7);
				String bDiscription = resultSet.getString(8);
				System.out.println(bID+" "+bName+" "+bAuthor+" "+bGenre+" "
				+bPrice+" "+bPublishers+" "+bPublishingdate+" "+bDiscription);
				Book book = new Book(bID, bName, bAuthor, bGenre, bPrice, bPublishers, bPublishingdate, bDiscription);
				al.add(book);
			}
			return al;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Book update(int bookID) {
		try {
			preparedStatement = connection.prepareStatement("select * from bookbydeepak where bid=?");
			preparedStatement.setInt(1, bookID);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				int bID = resultSet.getInt(1);
				String bName = resultSet.getString(2);
				String bAuthor = resultSet.getString(3);
				String bGenre = resultSet.getString(4);
				int bPrice = resultSet.getInt(5);
				String bPublishers = resultSet.getString(6);
				String bPublishingdate = resultSet.getString(7);
				String bDiscription = resultSet.getString(8);
				/*System.out.println(bID+" "+bName+" "+bAuthor+" "+bGenre+" "
				+bPrice+" "+bPublishers+" "+bPublishingdate+" "+bDiscription);*/
				Book book = new Book(bID, bName, bAuthor, bGenre, bPrice, bPublishers, bPublishingdate, bDiscription);
				return book;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void delete(int bookID) {
		
		try {
			preparedStatement = connection.prepareStatement("delete from bookbydeepak where bid=?");
			preparedStatement.setInt(1, bookID);
			preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void update2(Book book){
		System.out.println(book);
		try {
			preparedStatement = connection.prepareStatement("update bookbydeepak set bname=?,bauthor=?,bgenre=?,bprice=?,bpublisher=?,bpublishingdate=to_date(?,'YYYY-MM-DD'),bdiscription=? where bid=? ");
			preparedStatement.setString(1, book.getbName());
			preparedStatement.setString(2, book.getbAuthor());
			preparedStatement.setString(3, book.getbGenre());
			preparedStatement.setInt(4, book.getbPrice());
			preparedStatement.setString(5, book.getbPublisher());
			preparedStatement.setString(6, book.getbPublishingDate());
			preparedStatement.setString(7, book.getbDiscription());
			preparedStatement.setInt(8, book.getbID());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
