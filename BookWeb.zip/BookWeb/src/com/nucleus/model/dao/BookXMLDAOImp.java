package com.nucleus.model.dao;

import java.util.List;

import com.nucleus.model.domain.Book;

public class BookXMLDAOImp implements BookDAO{

	@Override
	public void save(Book book) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Book view(int bookID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book update(int bookID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int bookID) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update2(Book book) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Book> view() {
		// TODO Auto-generated method stub
		return null;
	}

}
