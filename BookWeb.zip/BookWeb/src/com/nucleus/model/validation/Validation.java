package com.nucleus.model.validation;

public class Validation {

}
