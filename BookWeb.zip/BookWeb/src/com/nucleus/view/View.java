package com.nucleus.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.model.domain.Book;

/**
 * Servlet implementation class View
 */
@WebServlet("/View")
public class View extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public View() {
        super();
    }

	private void view(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		//response.setContentType("text/html");
		Book bookDetails = (Book)request.getAttribute("bookdetails");
		/*if(bookDetails==null)
		{	
			response.setContentType("text/html");
			out.println("Book Does not Exist");
	        RequestDispatcher rd=request.getRequestDispatcher("/HomePage.html");  
	        rd.include(request, response);
		}else
		{
			*/int bID = bookDetails.getbID();	
			String bname = bookDetails.getbName();
			String bAuthor = bookDetails.getbAuthor();
			String bGenre = bookDetails.getbGenre();
			int bPrice = bookDetails.getbPrice();
			String bPublishers = bookDetails.getbPublisher();
			String date[]=bookDetails.getbPublishingDate().split(" ");
			String bPublishingDate = date[0];
			String bDiscription = bookDetails.getbDiscription();
			out.println("<html>");
			out.println("<h1 align=center>Book Details</h1>");
			out.println("<body><style>.center {padding: 70px 0;border: 3px solid green;text-align: center;}</style>");
			out.println("<table style=width:100% class=center> ");
			out.println("<tr><td><lable>ID</td><td>"+bID+"</td></tr>");
			out.println("<tr><td><lable>Name</td><td>"+bname+"</td></tr>");
			out.println("<tr><td><lable>Author Name</td><td>"+bAuthor+"</td></tr>");
			out.println("<tr><td><lable>Genre</td><td>"+bGenre+"</td></tr>");
			out.println("<tr><td><lable>Price</td><td>"+bPrice+"</td></tr>");
			out.println("<tr><td><lable>Publishers</td><td>"+bPublishers+"</td></tr>");
			out.println("<tr><td><lable>Publishing Date</td><td>"+bPublishingDate+"</td></tr>");
			out.println("<tr><td><lable>Discription</td><td>"+bDiscription+"</td></tr>");
			out.println("</table></body></html>");
		//}
		//out.println(bookDetails);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		view(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		view(request,response);
	}

}
