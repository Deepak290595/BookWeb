package com.nucleus.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.model.domain.Book;

/**
 * Servlet implementation class ViewAll
 */
@WebServlet("/ViewAll")
public class ViewAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAll() {
        super();
        // TODO Auto-generated constructor stub
    }
	private void viewall(HttpServletRequest request,HttpServletResponse response) throws IOException {
		ArrayList<Book> al =(ArrayList<Book>) request.getAttribute("aldetails");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<h1 align=center>Book Details</h1>");
		for (int i = 0; i < al.size(); i++) {
			int bID = al.get(i).getbID();	
			String bname = al.get(i).getbName();
			String bAuthor = al.get(i).getbAuthor();
			String bGenre = al.get(i).getbGenre();
			int bPrice = al.get(i).getbPrice();
			String bPublishers = al.get(i).getbPublisher();
			String date[]=al.get(i).getbPublishingDate().split(" ");
			String bPublishingDate = date[0];
			String bDiscription = al.get(i).getbDiscription();
			out.println("<body><style>.center {padding: 70px 0;border: 3px solid green;text-align: center;}</style>");
			out.println("<table style=width:100% class=center> ");
			out.println("<tr><td><lable>ID</td><td>"+bID+"</td></tr>");
			out.println("<tr><td><lable>Name</td><td>"+bname+"</td></tr>");
			out.println("<tr><td><lable>Author Name</td><td>"+bAuthor+"</td></tr>");
			out.println("<tr><td><lable>Genre</td><td>"+bGenre+"</td></tr>");
			out.println("<tr><td><lable>Price</td><td>"+bPrice+"</td></tr>");
			out.println("<tr><td><lable>Publishers</td><td>"+bPublishers+"</td></tr>");
			out.println("<tr><td><lable>Publishing Date</td><td>"+bPublishingDate+"</td></tr>");
			out.println("<tr><td><lable>Discription</td><td>"+bDiscription+"</td></tr>");
			out.println("</table>");
		}
		out.println("</body></html>");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		viewall(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		viewall(request,response);
	}

}
